function kickDangKy() {
    window.location = "dangky.html";
}